import os

class Config:
    API_KEY = os.environ.get('API_KEY') or '150dae67776e945e520ac70e5ecaac21'